# Spazzo

A social platform for UI/UX designers to showcase their work. (coming soon.. :D )

`Prototype`   

<img src="assets/demo1.jpg" alt="pc" width="50%"/> 

<img src="assets/ss.jpeg" alt="smartphone" width="50%"/> 


### Contributors 
<a href="https://adithyabhat.com"><img src="assets/contributors/adithya.png" alt="adithya" width="100px"></a> &nbsp;&nbsp; <a href="https://www.linkedin.com/in/arjun-devappa-a6085114a"><img src="assets/contributors/arjun.jpeg" alt="arjun" width="100px"></a> &nbsp;&nbsp;  <a href="https://www.linkedin.com/in/anusha-acharya-b783a2130"><img src="assets/contributors/anusha.jpeg" alt="arjun" width="100px"></a>
